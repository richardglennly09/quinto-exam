<html>
    <body>
        <h1>Tasks:  <?php echo e($name); ?></h1>
        <h4><b>Due Date:</b><span><?php echo e($due_date); ?></span></h4>
        <h4><b>Description:</b><span><?php echo e($description); ?></span></h4>
        <h4><b>Status:</b><span><?php echo e($status); ?></span></h4>
    </body>
</html>
<?php /**PATH /Users/dice205dev/Herd/exam-laravel/resources/views/email/create_task.blade.php ENDPATH**/ ?>