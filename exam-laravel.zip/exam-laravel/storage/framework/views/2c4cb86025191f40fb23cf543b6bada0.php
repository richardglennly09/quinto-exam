<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title><?php echo e($title ?? 'Page Title'); ?></title>
        <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
        <script >window.Wireui = {hook(hook, callback) {window.addEventListener(`wireui:${hook}`, () => callback())},dispatchHook(hook) {window.dispatchEvent(new Event(`wireui:${hook}`))}}</script>
<script src="http://exam-laravel.test/wireui/assets/scripts?id=eac37e3099acafcb5036e20dd54a70e9" defer ></script>
    </head>
    <body>
        <?php echo e($slot); ?>

    </body>
</html>
<?php /**PATH /Users/dice205dev/Herd/exam-laravel/resources/views/components/layouts/app.blade.php ENDPATH**/ ?>