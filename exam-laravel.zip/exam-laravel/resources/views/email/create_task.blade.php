<html>
    <body>
        <h1>Tasks:  {{$name}}</h1>
        <h4><b>Due Date:</b><span>{{$due_date}}</span></h4>
        <h4><b>Description:</b><span>{{$description}}</span></h4>
        <h4><b>Status:</b><span>{{$status}}</span></h4>
    </body>
</html>
